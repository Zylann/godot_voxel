/**
 * \file
 *
 * (C) 2018 Microsoft, Inc.
 *
 */
#ifndef _MONO_UTILS_FORWARD_
#define _MONO_UTILS_FORWARD_

typedef struct _MonoDomain MonoDomain;
typedef struct _MonoJitInfo MonoJitInfo;

#endif
